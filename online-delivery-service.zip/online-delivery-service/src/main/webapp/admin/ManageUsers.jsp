<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="modal.*, utils.*, java.util.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #e8f5e9;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        h1, h2 {
            color: #1976d2;
            margin-bottom: 20px;
        }

        .nav-links {
            margin-bottom: 30px;
        }

        .nav-links a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2196f3;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
            transition: background-color 0.3s;
        }

        .nav-links a:hover {
            background-color: #1976d2;
        }

        .content-section {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        form {
            max-width: 600px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .delete-form input[type="submit"] {
            background-color: #f44336;
        }

        .delete-form input[type="submit"]:hover {
            background-color: #d32f2f;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #2196f3;
            color: white;
            white-space: nowrap;
        }

        tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .user-actions {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            margin-top: 10px;
        }

        .role-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.9em;
            font-weight: bold;
        }

        .role-customer {
            background-color: #e3f2fd;
            color: #1976d2;
        }

        .role-restaurant {
            background-color: #fff3e0;
            color: #f57c00;
        }

        .role-delivery {
            background-color: #e8f5e9;
            color: #388e3c;
        }

        .role-admin {
            background-color: #f3e5f5;
            color: #7b1fa2;
        }

        @media screen and (max-width: 768px) {
            .content-section {
                margin: 10px;
                padding: 15px;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .nav-links a {
                display: block;
                margin-bottom: 10px;
            }

            td {
                min-width: 120px;
            }

            .user-actions form {
                margin: 0;
            }
        }
    </style>
</head>
<body>
<h1>Manage Users</h1>
<div class="nav-links">
    <a href="../LogoutServlet">Logout</a>
    <a href="Dashboard.jsp">Back to Dashboard</a>
</div>

<div class="content-section">
    <h2>Add User</h2>
    <form action="../UserServlet" method="post">
        <input type="hidden" name="action" value="add">
        <div class="form-group">
            <label for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName" required>
        </div>
        <div class="form-group">
            <label for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phoneNumber" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="customer">Customer</option>
                <option value="restaurant">Restaurant</option>
                <option value="delivery">Delivery</option>
                <option value="admin">Admin</option>
            </select>
        </div>
        <div class="form-group">
            <input type="submit" value="Add User">
        </div>
    </form>
</div>

<div class="content-section">
    <h2>Users List</h2>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <% for (User user : UserHandle.getUsers()) { %>
                <tr>
                    <td><%= user.getUserId() %></td>
                    <td><%= user.getFirstName() %> <%= user.getLastName() %></td>
                    <td><%= user.getEmail() %></td>
                    <td><%= user.getPhoneNumber() %></td>
                    <td><span class="role-badge role-<%= user.getRoleDescription().toLowerCase() %>"><%= user.getRoleDescription() %></span></td>
                    <td>
                        <div class="user-actions">
                            <form action="../UserServlet" method="post">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="userId" value="<%= user.getUserId() %>">
                                <div class="form-group">
                                    <label for="firstName-<%= user.getUserId() %>">First Name:</label>
                                    <input type="text" id="firstName-<%= user.getUserId() %>" name="firstName" value="<%= user.getFirstName() %>">
                                </div>
                                <div class="form-group">
                                    <label for="lastName-<%= user.getUserId() %>">Last Name:</label>
                                    <input type="text" id="lastName-<%= user.getUserId() %>" name="lastName" value="<%= user.getLastName() %>">
                                </div>
                                <div class="form-group">
                                    <label for="email-<%= user.getUserId() %>">Email:</label>
                                    <input type="email" id="email-<%= user.getUserId() %>" name="email" value="<%= user.getEmail() %>">
                                </div>
                                <div class="form-group">
                                    <label for="phone-<%= user.getUserId() %>">Phone:</label>
                                    <input type="text" id="phone-<%= user.getUserId() %>" name="phoneNumber" value="<%= user.getPhoneNumber() %>">
                                </div>
                                <div class="form-group">
                                    <label for="password-<%= user.getUserId() %>">Password:</label>
                                    <input type="password" id="password-<%= user.getUserId() %>" name="password" value="<%= user.getPassword() %>">
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Update">
                                </div>
                            </form>
                            <form action="../UserServlet" method="post" class="delete-form">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="userId" value="<%= user.getUserId() %>">
                                <div class="form-group">
                                    <input type="submit" value="Delete">
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
                <% } %>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>